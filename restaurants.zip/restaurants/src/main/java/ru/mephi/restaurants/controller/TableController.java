package ru.mephi.restaurants.controller;

import ru.mephi.restaurants.domain.table.Table;
import ru.mephi.restaurants.domain.table.TableDto;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/table")
@RequiredArgsConstructor
public class TableController {

}
