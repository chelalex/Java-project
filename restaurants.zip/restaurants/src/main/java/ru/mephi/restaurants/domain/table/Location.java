package ru.mephi.restaurants.domain.table;

enum Location {
    TERRACE,
    HALL
}
